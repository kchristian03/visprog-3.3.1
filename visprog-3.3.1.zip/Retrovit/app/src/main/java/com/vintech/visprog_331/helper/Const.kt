package com.vintech.visprog_331.helper

object Const {

    const val BASE_URL = "https://api.themoviedb.org/3/"
    const val API_KEY = "490cbaf07ddb978789201eabde448a15"

}