package com.vintech.visprog_331

import dagger.hilt.android.HiltAndroidApp
import android.app.Application

@HiltAndroidApp
class Application: Application() {
}