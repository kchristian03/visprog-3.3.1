package com.vintech.visprog_331.model

data class Dates(
    val maximum: String,
    val minimum: String
)